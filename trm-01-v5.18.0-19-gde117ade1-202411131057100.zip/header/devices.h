#ifndef __DEVICE_TYPES_H__
#define __DEVICE_TYPES_H__
/* ======================================================================== */
/* [INCL] Includes                                                          */
/* ======================================================================== */

/* ======================================================================== */
/* [DEFS] Defines                                                           */
/* ======================================================================== */
#define FACEPLATE_TYPE_OFFSET_BITS (5)
/* ======================================================================== */
/* [TYPE] Type definitions                                                  */
/* ======================================================================== */

// Base device type enum definition
enum mesh_command_base_device_type_nr_enum {
    mesh_command_base_device_type_unknown        = 0,
    mesh_command_base_device_type_dim_01         = 1,
    mesh_command_base_device_type_dim_02         = 2,
    mesh_command_base_device_type_ctr_01         = 3,
    mesh_command_base_device_type_group_0        = 4,
    mesh_command_base_device_type_led_10         = 5,
    mesh_command_base_device_type_group_1        = 6,
    mesh_command_base_device_type_group_2        = 7,
    mesh_command_base_device_type_group_3        = 8,
    mesh_command_base_device_type_group_4        = 9,
    mesh_command_base_device_type_group_5        = 10,
    mesh_command_base_device_type_dim_01_2p      = 11,
    mesh_command_base_device_type_dal_01         = 12,
    mesh_command_base_device_type_dev_01         = 13,
    mesh_command_base_device_type_dim_01_lc      = 14,
    mesh_command_base_device_type_dim_02_lc      = 15,
    mesh_command_base_device_type_jal_01         = 16,
    mesh_command_base_device_type_rel_01_2p      = 17,
    mesh_command_base_device_type_rel_02         = 18,
    mesh_command_base_device_type_ext_01         = 19,
    mesh_command_base_device_type_mix_01         = 20,
    mesh_command_base_device_type_trm_02         = 21,
    mesh_command_base_device_type_dim_01_lc_2    = 22,
    mesh_command_base_device_type_led_10_h       = 23,
    mesh_command_base_device_type_dim_02_lc_2    = 24,
    mesh_command_base_device_type_dim_01_2p_lc_2 = 25,
    mesh_command_base_device_type_reserved_08    = 26,
    mesh_command_base_device_type_reserved_09    = 27,
    mesh_command_base_device_type_reserved_10    = 28,
    mesh_command_base_device_type_reserved_11    = 29,
    mesh_command_base_device_type_reserved_12    = 30,
    mesh_command_base_device_type_extended       = 31
};

enum mesh_command_device_type_nr_enum {
    mesh_command_device_type_unknown        = mesh_command_base_device_type_unknown,
    mesh_command_device_type_dim_01         = mesh_command_base_device_type_dim_01,
    mesh_command_device_type_dim_02         = mesh_command_base_device_type_dim_02,
    mesh_command_device_type_ctr_01         = mesh_command_base_device_type_ctr_01,
    mesh_command_device_type_led_10         = mesh_command_base_device_type_led_10,
    mesh_command_device_type_dim_01_2p      = mesh_command_base_device_type_dim_01_2p,
    mesh_command_device_type_dal_01         = mesh_command_base_device_type_dal_01,
    mesh_command_device_type_dev_01         = mesh_command_base_device_type_dev_01,
    mesh_command_device_type_dim_01_lc      = mesh_command_base_device_type_dim_01_lc,
    mesh_command_device_type_dim_02_lc      = mesh_command_base_device_type_dim_02_lc,
    mesh_command_device_type_jal_01         = mesh_command_base_device_type_jal_01,
    mesh_command_device_type_rel_01_2p      = mesh_command_base_device_type_rel_01_2p,
    mesh_command_device_type_rel_02         = mesh_command_base_device_type_rel_02,
    mesh_command_device_type_ext_01         = mesh_command_base_device_type_ext_01,
    mesh_command_device_type_mix_01         = mesh_command_base_device_type_mix_01,
    mesh_command_device_type_trm_02         = mesh_command_base_device_type_trm_02,
    mesh_command_device_type_dim_01_lc_2    = mesh_command_base_device_type_dim_01_lc_2,
    mesh_command_device_type_dim_02_lc_2    = mesh_command_base_device_type_dim_02_lc_2,
    mesh_command_device_type_dim_01_2p_lc_2 = mesh_command_base_device_type_dim_01_2p_lc_2,
    mesh_command_device_type_led_10_h       = mesh_command_base_device_type_led_10_h,

    // Group 0
    mesh_command_device_type_gwy_01         = (mesh_command_base_device_type_group_0 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_led_75         = (mesh_command_base_device_type_group_0 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_rol_01         = (mesh_command_base_device_type_group_0 | (2 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_trm_01         = (mesh_command_base_device_type_group_0 | (3 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_vri_03         = (mesh_command_base_device_type_group_0 | (4 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_fak_01         = (mesh_command_base_device_type_group_0 | (5 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_mtr_01         = (mesh_command_base_device_type_group_0 | (6 << FACEPLATE_TYPE_OFFSET_BITS)),

    // Group 1
    mesh_command_device_type_wph_01         = (mesh_command_base_device_type_group_1 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_wph_01_lc      = (mesh_command_base_device_type_group_1 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_wms_01         = (mesh_command_base_device_type_group_1 | (2 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_win_01         = (mesh_command_base_device_type_group_1 | (3 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_wpd_01         = (mesh_command_base_device_type_group_1 | (4 << FACEPLATE_TYPE_OFFSET_BITS)),

    // Group 2
    mesh_command_device_type_ccl_01         = (mesh_command_base_device_type_group_2 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_ccl_01_lc      = (mesh_command_base_device_type_group_2 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_sqr_01         = (mesh_command_base_device_type_group_2 | (2 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_out_01         = (mesh_command_base_device_type_group_2 | (3 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_out_02         = (mesh_command_base_device_type_group_2 | (4 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_dwn_01         = (mesh_command_base_device_type_group_2 | (5 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_dwn_02         = (mesh_command_base_device_type_group_2 | (6 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_bnk_01         = (mesh_command_base_device_type_group_2 | (7 << FACEPLATE_TYPE_OFFSET_BITS)),

    // Group 3
    mesh_command_device_type_spr_01         = (mesh_command_base_device_type_group_3 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_spd_01         = (mesh_command_base_device_type_group_3 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),

    // Group 4
    mesh_command_device_type_dwn_01_lc      = (mesh_command_base_device_type_group_4 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_dwn_02_lc      = (mesh_command_base_device_type_group_4 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),
    // Group 5
    mesh_command_device_type_wrt_01         = (mesh_command_base_device_type_group_5 | (0 << FACEPLATE_TYPE_OFFSET_BITS)),
    mesh_command_device_type_wrt_01_lc      = (mesh_command_base_device_type_group_5 | (1 << FACEPLATE_TYPE_OFFSET_BITS)),

};


#endif /* __DEVICE_TYPES_H__ */
