#ifndef __PLED_GATT_SPECIAL_COMMANDS_H__
#define __PLED_GATT_SPECIAL_COMMANDS_H__
/* ================================================================================================================= */
/* Copyright (C) 2024 Plejd AB. All rights reserved.                                                                 */
/*                                                                                                                   */
/* Unauthorized copying of this file, via any medium is strictly prohibited.                                         */
/* This file is confidential and proprietary.                                                                        */
/*                                                                                                                   */
/* ================================================================================================================= */
/**
 * @file special_commands.h
 * @author Jacob Andersson
 * @date 2024-07-22
 * @brief Interface for special commands
 *
 *
 */
/* ================================================================================================================= */
/* ================================================================================================================= */
/* [INCL] Includes                                                                                                   */
/* ================================================================================================================= */
/* ------------------------  Standard  ------------------------------------ */

/* --------------------------  SDK  --------------------------------------- */

/* -------------------------  Plejd  -------------------------------------- */

/* -------------------------  Local  -------------------------------------- */

/* ================================================================================================================= */
/* [DEFS] Defines                                                                                                    */
/* ================================================================================================================= */

/* ================================================================================================================= */
/* [TYPE] Type definitions                                                                                           */
/* ================================================================================================================= */

typedef enum special_commands_e {
    eSPECIAL_COMMANDS_NO_COMMAND                        = 0x0000,
    eSPECIAL_COMMANDS_RESET_SYSTEM_AFTER_NEXT_POWER_UP  = 0x0101,
    eSPECIAL_COMMANDS_INDICATE_TO_USER                  = 0x0202,
    eSPECIAL_COMMANDS_DEPRECATED                        = 0x0303, /* Used to be eSPECIAL_COMMANDS_RF_CHANNEL_XX */
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_S1_ACTIVITY     = 0x0C0C,
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_S2_ACTIVITY     = 0x0D0D,
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_S3_ACTIVITY     = 0x0E0E,
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_S4_ACTIVITY     = 0x0F0F,
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_S5_ACTIVITY     = 0x1010,
    eSPECIAL_COMMANDS_INDICATE_TO_PHONE_BOOTED          = 0x1111, /* Indicate if device has booted within 60 s */
    eSPECIAL_COMMANDS_INDICATE_TO_USER2                 = 0x1212,
    eSPECIAL_COMMANDS_ENTER_DFU                         = 0x1313,
    eSPECIAL_COMMANDS_INDICATE_BY_PAYLOAD               = 0x1414,

    /* TRM specific special commands */
    eSPECIAL_COMMANDS_TRM_GRAPHIC_TRANSFER              = 0x1515, /* Prepare gfx update, set batch size in payload. */
    eSPECIAL_COMMANDS_TRM_GET_LANGUAGE_SLOT_IN_USE      = 0x1516, /* Get language slot in use. */
    eSPECIAL_COMMANDS_TRM_SET_LANGUAGE_SLOT_IN_USE      = 0x1517, /* Set language slot in use. */
    eSPECIAL_COMMANDS_TRM_GET_IMAGE_BANK_METADATA       = 0x151B, /* Get image bank metadata */

    eSPECIAL_COMMANDS_TRM_REMOVED_0                     = 0x1518, /* Was eSPECIAL_COMMANDS_TRM_GET_LANGUAGE_IDS */
    eSPECIAL_COMMANDS_TRM_REMOVED_1                     = 0x1519, /* Was eSPECIAL_COMMANDS_TRM_GET_CONTENT_VERSIONS */
    eSPECIAL_COMMANDS_TRM_REMOVED_2                     = 0x151A, /* Was eSPECIAL_COMMANDS_TRM_GET_USER_INTERFACE_VERSIONS */

} special_commands_t;

#endif /* __PLED_GATT_SPECIAL_COMMANDS_H__ */
