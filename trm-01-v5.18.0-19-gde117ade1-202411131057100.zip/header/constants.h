/* ======================================================================== */
/* Copyright (C) 2019 X. All rights reserved.                               */
/*                                                                          */
/* Unauthorized copying of this file, via any medium is strictly prohibited.*/
/* This file is confidential and proprietary.                               */
/*                                                                          */
/* ======================================================================== */
/**
 * @file mesh.h
 * @author alex
 * @date 1 Jul 2019
 * @brief X
 *
 * X
 */
/* ======================================================================== */

#ifndef PLEJD_MESH_INCLUDE_PLEJD_TOMOVE_MESH_H_
#define PLEJD_MESH_INCLUDE_PLEJD_TOMOVE_MESH_H_

//UUID used for mesh service
#define SERVICE_UUID {0xB5, 0x91, 0x73, 0x95, 0x0C, 0x04, 0x45, 0xBE, 0x26, 0x47, 0x85, 0x60, 0x01, 0x00, 0xBA, 0x31}
#define PLEJD_COMPANY_ID	0x0377
#define DH_COMMON_MOD	15734018190158744081ULL //(this number must be prime)
#define DH_COMMON_BASE	2 //This number must be prime and can be small, 2 or 3 is ok

#endif /* PLEJD_MESH_INCLUDE_PLEJD_TOMOVE_MESH_H_ */
