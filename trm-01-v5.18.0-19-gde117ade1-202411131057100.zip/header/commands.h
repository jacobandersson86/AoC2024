/* ======================================================================== */
/* Copyright (C) 2019 X. All rights reserved.                               */
/*                                                                          */
/* Unauthorized copying of this file, via any medium is strictly prohibited.*/
/* This file is confidential and proprietary.                               */
/*                                                                          */
/* ======================================================================== */
/**
 * @file commands.h
 * @author alex
 * @date 1 Jul 2019
 * @brief X
 *
 * X
 */
/* ======================================================================== */

#ifndef PLEJD_MESH_INCLUDE_PLEJD_MESH_COMMANDS_H_
#define PLEJD_MESH_INCLUDE_PLEJD_MESH_COMMANDS_H_

enum mesh_commands_enum
{
    //AVAILABLE COMMANDS: Supported commands
    //========================================================================================================
    // 0x0000 - 0x0031 (     0 -     49)                                    ----- STANDARD MESH --------------------------------------------------------------------------------
    mesh_command_device_type_nr                                   = 0x0000, // Get/Set nr of this device type, payload is of type enum mesh_command_device_type_nr_enum
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_device_addr                                      = 0x0003, // Get device local Bluetooth address as payload[0-5]
    mesh_command_device_fw_version                                = 0x0004, // Get the firmware version, smaller value is older, higher value is newer
    mesh_command_number_of_inputs                                 = 0x0005, // Get number of inputs on the device
    mesh_command_number_of_outputs                                = 0x0006, // Get number of outputs on the device
    mesh_command_input_groups                                     = 0x0007, // Get/Set, if 2 byte payload for set, payload[0] is input nr, payload[1] is index to remove. if 3 byte payload for set, add input nr #payload[0] add group index payload[1], payload[2] is the access type as mesh_command_in_out_group_access_enum, if only one byte payload is sent, all groups are removed, when geting, set only the first 2 byte, payload[0] is the input, payload[1] is the selected index in the internal table
    mesh_command_output_groups                                    = 0x0008, // Get/Set, if 2 byte payload for set, payload[0] is output nr, payload[1] is index to remove. if 3 byte payload for set, add output nr #payload[0] add group index payload[1], payload[2] is the access type as mesh_command_in_out_group_access_enum, if only one byte payload is sent, all groups are removed, when geting, set only the first 2 byte, payload[0] is the input, payload[1] is the selected index in the internal table
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_get_internal_temperature                         = 0x000d, // Get the temperature of the CPU in degc (int16)payload[0-1]
    mesh_command_get_max_internal_temperature                     = 0x000e, // Get/set the max temperature of the CPU in degc (int16)payload[0-1], only 21->149 can be set
    mesh_command_get_external_temperature                         = 0x000f, // Get the temperature of the product in degc (int16)payload[0-1]
    mesh_command_get_max_external_temperature                     = 0x0010, // Get/set the max temperature of the product in degc (int16)payload[0-1], only 21->149 can be set
    mesh_command_factory_reset                                    = 0x0011, // Do factory reset, payload[0->3] must be 0xAA 0xBB 0xCC 0xDD to avoid spurious factory resets
    mesh_command_enter_dfu                                        = 0x0031,
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_event_prepare                                    = 0x0015, // Set preparation for next event, next event(button click) will cause mesh_command_event_fired to be broadcasted from the first unit that sees a click
    mesh_command_event_fired                                      = 0x0016, // Set Nodes will send this command when prepared for a event and a click has occured, payload[0] is the nodes index, payload[1] is input nr
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_system_time                                      = 0x001b, // Get/Set of the system time, payload[0->3] is unix timestamp, (mesh_command_time_type_enum) payload[4]=0 for exact time(from phone), everyone should use this time, payload[4]=1 for non exact time(from node), everyone with a timestap atleast one minute smaller should use this time., this should be local wintertime
    mesh_command_system_time_settings                             = 0x0060, // Configure settings for system time.
    mesh_command_virtual_time                                     = 0x101b,
    mesh_command_summer_winter_time_settings                      = 0x001c, // Get/Set the summer/winter time settings, payload[0] is the type of summer winter time used as (enum summer_winter_time_type_enum), if summer_winter_time_type_custom is selected: (int16) payload[1-2] is the offset to be used from (date) payload[3-5] to (date) payload[6-8] where date is encoded as [month(0-11), day(1-31), hour(0-23)], if summer_winter_time_type_eu is selected then payload[1->2] as int16_t is the local UTC offset in minutes
    mesh_command_hardfault_reason                                 = 0x001d, // Get hardfault reason as payload[0->3] as uint32 of error code, payload[4->5] as (uint16_t) of line number and payload[6->] as string of file name
    mesh_command_remove_references_to_index                       = 0x001e, // remove all references to index #payload[0], this should be used when a node is remvoed from the mesh
    mesh_command_get_error                                        = 0x001f, // Get the error bitfield as payload[0->1] and latching errors in payload[2->3] as uint16_t with each bit corresponding to a error in error_reporting_error_enum, set with no payload to clear errors
    mesh_command_scene                                            = 0x0021, // execute scene #payload[0], this command is sent by nodes on index 2 but should be sent be app on index 0
    mesh_command_scene_stop                                       = 0x0061, // stop scene with scene_nr #payload[0]
    mesh_command_remove_references_to_scene                       = 0x0023, // remove all references to scene #payload[0]
    mesh_command_restart                                          = 0x0024, // When received with payload[0]=0xAA, the device will restart, when broadcast, first send 0xAB, then within 10seconds, send 0xBA
    mesh_command_get_attached_faceplate                           = 0x0025, // Get attached faceplate as enum faceplate_type_enum in payload[0]
    mesh_command_store_time_periodically                          = 0x0027, // Get/Set Payload[0] is bool of enable feature, Payload[1->2]=uint16_t of store time period in seconds, Payload[3->4]=int16_t of offset to add at boot.
    mesh_command_rf_parameters                                    = 0x0028, // Get/Set i_min as uint16_t of payload[0->1], i_max as uint16_t of payload[2->3] and k as uint16_t in payload[4->5]
    mesh_command_get_boot_attached_faceplate                      = 0x0029, // Get attached faceplate at boot as enum faceplate_type_enum in payload[0]
    mesh_command_dont_send_old_data                               = 0x002a, // Get/Set setting for sending old data on mesh (payload[0->1] 20ms cycles before deleting old data. 0 disables this feature)
    mesh_command_get_events                                       = 0x002b, // Get events (hard fault, overcurrent etc..) that has happened to this device. (get)Empty payload: Get events: u64[event flags]. (set)Broadcast empty paylaod: Reply=[index, 0, u64 events]. (set)Empty payload: clear all events
    mesh_command_hardfault_time                                   = 0x002c, // Get last hardfault time as payload[0->3] unix timestamp
    mesh_command_output_configure_scene                           = 0x002d, // See: https://plejd.gitlab.io/specifications/Scenariokonfiguration/
    mesh_command_system_time_status                               = 0x002e, // Get the status of all time sources (faceplate bat / product bat)
    mesh_command_rbc_packet_check                                 = 0x0030, // Enable/Disable the packet_is_valid() check in RBC mesh
    mesh_command_rbc_channel_config                               = 0x0056, // Configure RBC mesh channels and speed
    mesh_command_checksum                                         = 0x0057, // Configure the running mesh packet checksum
    mesh_command_radio_tx_power                                   = 0x0058, // Set mesh and ble TX power.
    mesh_command_settings_sync_verify                             = 0x005a,
    mesh_command_settings_sync_config                             = 0x005b,
    mesh_command_settings_sync_status                             = 0x005c,
    mesh_command_rx_channel_switch_periodicity                    = 0x005d, // Set the mesh rx channel switch periodicity, in µs, little endian U32.
    mesh_command_listen_before_talk                               = 0x005e, // Set the listen before talk time, in µs, little endian U32.

    // 0x0032 - 0x0095 (    50 -     99)                                    ------ TESTING -------------------------------------------------------------------------------------
    mesh_command_testing_get_zcd_frequency                        = 0x0032, // Get the ZCD frequency in Hz, payload[0] as uint8
    mesh_command_testing_get_gate_driver_rail_voltage             = 0x0033, // Get the gate driver rail voltage in mV, payload[0->1] as uint16
    mesh_command_testing_get_2V5_rail_voltage                     = 0x0034, // Get the 2V5 rail voltage in mV, payload[0->1] as uint16
    mesh_command_testing_flash_status                             = 0x0035, // Get the status of the FLASH chip in payload[0], 0 means that it is not operational, 1 means that it is operational
    mesh_command_testing_get_switch_inputs                        = 0x0036, // Get the switch inputs to the unit in payload[0] as bitfield for every input, input 0 is lsb(bit0)
    mesh_command_testing_send_factory_reset_and_send_carrier      = 0x0037, // Set, payload[0] is the frequency to send carrier at, before carrier is send a factory reset is done
    mesh_command_testing_worst_measured_environment               = 0x0038, // Set with empty payload to clear and Get with offset payload[0] as uint8_t
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_testing_set_face_plate_override                  = 0x003d, // Set with Payload[0] as mesh_command_testing_set_face_plate_override_enum
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_testing_dim_01_test_cycle_0                      = 0x003f, //
    mesh_command_testing_dim_01_test_cycle_1                      = 0x0040, //
    mesh_command_testing_dim_01_test_cycle_2                      = 0x0041, //
    mesh_command_testing_bat01_time                               = 0x0042, // Get/Set BAT01 time, payload[0->3] as uint32_t of unix time //TODO Replace with a common function for all device with builtin timer?
    mesh_command_testing_bat01_set_power                          = 0x0043, // Set, Payload[0] is 0 for no power and 1 for power
    mesh_command_testing_faceplate_raw_i2c                        = 0x0044, // Set to write to device Payload[0], addr Payload[1] data payload[2->x], get to read data from device Payload[0], addr payload[1], length payload[2]
    mesh_command_testing_dim_02_test_cycle_0                      = 0x0045, //
    mesh_command_testing_dim_02_test_cycle_1                      = 0x0046, //
    mesh_command_testing_dim_02_test_cycle_2                      = 0x0047, //
    mesh_command_testing_ctr_01_test_cycle_0                      = 0x0048, //
    mesh_command_testing_ctr_01_test_cycle_1                      = 0x0049, //
    mesh_command_testing_ctr_01_test_cycle_2                      = 0x004a, //
    mesh_command_testing_led_10_test_cycle_0                      = 0x004b, //
    mesh_command_testing_led_10_test_cycle_1                      = 0x004c, //
    mesh_command_testing_led_10_test_cycle_2                      = 0x004d, //
    mesh_command_testing_gwy_10_test_cycle_0                      = 0x004e, //
    mesh_command_testing_gwy_10_test_cycle_1                      = 0x004f, //
    mesh_command_testing_gwy_10_test_cycle_2                      = 0x0050, //
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_testing_test_cycle_0                             = 0x0051, // Device test cycle 0
    mesh_command_testing_test_cycle_1                             = 0x0052, // Device test cycle 1
    mesh_command_testing_test_cycle_2                             = 0x0053, // Device test cycle 2
    mesh_command_testing_test_cycle_3                             = 0x0054, // Device test cycle 3
    mesh_command_testing_test_cycle_4                             = 0x0055, // Device test cycle 4
    mesh_command_testing_device_info                              = 0x0059, // Testing command containing device information.
    // 0x0064 - 0x0095 (   100 -    149)                                    ------ PING/PONG -----------------------------------------------------------------------------------
    // 0x0096 - 0x00c8 (   150 -    199)                                    ------ OUTPUT GROUP --------------------------------------------------------------------------------
    mesh_command_group_output_level                               = 0x0096, // Set all output levels in group as uint16_t(payload[0-1]) from 0 to 2^16-1
    mesh_command_group_output_state                               = 0x0097, // Set all output states in group as a bool(payload[0]) from 0 to 1
    mesh_command_group_output_state_and_level                     = 0x0098, // Set all output states in group as a bool(payload[0]) from 0 to 1 and level as uint16_t(payload[1-2]) from 0 to 2^16-1
    mesh_command_group_output_announce                            = 0x009B, // Get the Node-Light-Table entry for the output that has group write access to the index the command is sent on.
    // 0x00c8 - 0x00f9 (   200 -    249)                                    ------ OUTPUT --------------------------------------------------------------------------------------
    mesh_command_output_state_and_level                           = 0x00c8, // Get/Set the output #payload[0] as a bool(payload[1]) from 0 to 1 and level as uint16_t(payload[2-3]) from 0 to 2^16-1
    mesh_command_output_min_level                                 = 0x00c9, // Get/Set the output min level #payload[0] as a uint16_t(payload[1-2]) from 0 to 2^16-1
    mesh_command_output_max_level                                 = 0x00ca, // Get/Set the output max level #payload[0] as a uint16_t(payload[1-2]) from 0 to 2^16-1
    mesh_command_output_speed                                     = 0x00cb, // Get/Set the output speed #payload[0] as a uint16_t(payload[1-2]) from 0 to 2^16-1 steps per ms
    mesh_command_output_start_level                               = 0x00cf, // Get/Set the output start level #payload[0] as a uint16_t(payload[1-2]) from 0 to 2^16-1
    mesh_command_output_start_time                                = 0x00d0, // Get/Set the output start time #payload[0] as a uint16_t(payload[1-2]) as 10ms units, max allowed is 500
    mesh_command_output_configure_announce                        = 0x00db,
    mesh_command_output_announce_suppress                         = 0x00dc,
    mesh_command_output_output_non_dimable_threshold              = 0x00d5, // Get/Set output # payload[0] as uint8_t, output_non_dimable_threshold as uint16_t in payload[1->2]
    mesh_command_output_boot_state_and_level                      = 0x00d7, // (TO DEPRECATE?) Get/Set for output #payload[0] boot state in payload[1] as bool and boot level in payload[2->3] as uint16_t, if only 1 byte payload last state and level are used, If 2 bytes of payload, last level but forced state is used
    mesh_command_output_time_from_off_to_min                      = 0x00a2, // Get/Set the time from off to min level for output payload[0] as uint16_t in payload[1->2] in 10ms units
    mesh_command_output_proximity_timer_configure                 = 0x00a3, // Get/Set configuration for proximity timer
    mesh_command_output_state_machine_configure                   = 0x00a4, // Get/Set configuration for output state machine
    mesh_command_output_install                                   = 0x00a5,
    mesh_command_output_window_tilt                               = 0x00ac, // Get the window tilt state for an output. Payload[0] is the output number.
    mesh_command_indicate                                         = 0x00a6, // Set to indicate output_nr as payload[0], optional MAC as payload[1-6] (previously called mesh_command_output_indicate)
    mesh_command_output_gamma_correction                          = 0x00a7,
    mesh_command_halogen_settings                                 = 0x00a8,
    mesh_command_osm_recover_level                                = 0x00a9,
    mesh_command_motion_as_manual_timeout                         = 0x00aa,
    mesh_command_reset_output_inhibit                             = 0x00ab,

    // 0x00fa - 0x012b (   250 -    299)                                    ------ CLICK ---------------------------------------------------------------------------------------
    mesh_command_input_click_functionality                        = 0x00fa, // Get/Set the click functionality of button #payload[0] as enum mesh_commands_input_click_functionality_enum cast from payload[1]
    mesh_command_input_click_functionality_scene                  = 0x00fb, // Get/Set input_click_settings using memory map method. //Payload SET with 5 bytes - (bool) #payload[4] - choose if scene should be activated or deactivated on click.
    // 0x012c - 0x015d (   300 -    349)                                    ------ DOUBLE CLICK --------------------------------------------------------------------------------
    mesh_command_input_double_click_functionality                 = 0x012c, // Get/Set the double click functionality of button #payload[0] as enum mesh_commands_input_click_functionality_enum cast from payload[1]
    mesh_command_input_double_click_functionality_scene           = 0x012d, // Get/Set the scene section #payload[1] for button #payload[0] double click as scene #payload[2], enabled (bool) as payload[3], set with 1 byte payload to clear all scenes for that button, get with only send 2 byte of the payload
                                                                            //Payload SET with 5 bytes - (bool) #payload[4] - choose if scene should be activated or deactivated on double click.
    // 0x015e - 0x018f (   350 -    399)                                    ------ DIMMER --------------------------------------------------------------------------------------
    mesh_command_input_dim_functionality                          = 0x015e, // Get/Set the dim functionality of button #payload[0] as enum mesh_commands_input_dim_functionality_enum cast from payload[1]
    //                                                              ------  // - - - - - - - - - - - - - - - - - - -
    mesh_command_input_edge_functionality                         = 0x0161, // Get/Set the edge functionality of button #payload[0] as enum mesh_commands_input_edge_functionality_enum cast from payload[1]
    mesh_command_input_rotate_functionality                       = 0x0162, // Get/Set the rotate functionality of button #payload[0] as enum mesh_commands_input_rotate_functionality_enum cast from payload[1]
    mesh_command_input_push_rotate_functionality                  = 0x0163,
    mesh_command_input_color_tune_config                          = 0x0164, // GET/SET speed scaler and override flag for color tune of button #payload[0] as uint16_t(payload[1-2]) as a scaler, bool(payload[3]) as override flag.
    // 0x0190 - 0x01c1 (   400 -    449)                                    ------ INPUT ---------------------------------------------------------------------------------------
    mesh_command_input_dim_speed                                  = 0x0190, // Get/Set dim speed for input #payload[0] as uint16_t(payload[1-2]) 0-2^16-1 steps per 10ms
    mesh_command_input_debounce                                   = 0x0191, // Get/Set debounce time for input #payload[0] as uint16_t(payload[1-2]) 0-2^16-1 in 10ms units
    mesh_command_input_click_max_time                             = 0x0192, // Get/Set click max time for input #payload[0] as uint16_t(payload[1-2]) 0-2^16-1 in 10ms units, this the threshold between click and dim
    mesh_command_input_power_push_time                            = 0x0193, // Get/Set power push time for input #payload[0] as uint16_t(payload[1-2]) 0-2^16-1 in 10ms units
    mesh_command_input_double_click_time                          = 0x0194, // Get/Set double click minimi time for input #payload[0] as uint16_t(payload[1-2]) 0-2^16-1 in 10ms units, this the minimum time that the button can be released between two clicks to be considered a double click
    mesh_command_input_state_and_level                            = 0x0195, // Get the input level #payload[0] ,response: bool(payload[0]) from 0 to 1 and level as uint16_t(payload[1-2]) from 0 to 2^16-1
    mesh_command_input_first_push_dim_direction                   = 0x019a, // Get/Set for input #payload[0], threshold level in payload[1] as uint8_t and timeout in seconds in payload[2]
    mesh_command_input_encoder_inhibits                           = 0x019c, // Get/Set for input #payload[0], number of 20ms enocder inhibits as payload[1->6]
    mesh_command_input_motion_configure                           = 0x019d, // Get/Set input as a motion timer (requires edge functionality to be motion_only_positive_repeat) (Get/set) payload[0] is input nr, (Set) payload[1-2] is polling rate in 20ms, optinonal payload[3-6] is duration and flags for setOutput proximity timer
    mesh_command_input_install                                    = 0x019e,
    mesh_command_input_encoder_speed                              = 0x019f, // Get/Set speed and acceleration for encoder
    mesh_command_input_event_config                               = 0x01a0, // Get/Set input event configuration, input as #payload[0], event as #payload[1], type as #payload[1], functionality as #payload[2] and target as #payload[3]
    mesh_command_input_window_move_speed                          = 0x01a1, // Get/set speed when performing a move. If 0, it defaults to the outputs speed.
    mesh_command_input_window_endstop_speed                       = 0x01a2, // Get/set speed when going to an endstop. If 0, it defaults to the outputs speed.
    mesh_command_input_window_direction_timeout                   = 0x01a3, // Get/set timeout for when resetting the direction. Time in seconds.
    mesh_command_input_window_move_acceleration                   = 0x01a4, // Get/set acceleration when performing a move. If 0, it defaults to the outputs acceleration.
    mesh_command_input_window_endstop_acceleration                = 0x01a5, // Get/set acceleration when going to an endstop. If 0, it defaults to the outputs acceleration.
    mesh_command_input_window_stop_acceleration                   = 0x01a6, // Get/set acceleration when commanding a stop. If 0, it defaults to the outputs acceleration.
    mesh_command_input_window_button_stuck_threshold              = 0x01a7, // Get/set the threshold for when a button is considered stuck. Time in cycles.
    // 0x01c2 - 0x01f3 (   450 -    499)                                    ------ OUTPUT --------------------------------------------------------------------------------------
    // 0x01f4 - 0x0225 (   500 -    549)                                    ------ LED10 ---------------------------------------------------------------------------------------
    // 0x0226 - 0x0257 (   550 -    599)                                    ------ POWER ---------------------------------------------------------------------------------------
    // 0x0258 - 0x0289 (   600 -    649)                                    ------ TIME EVENT ----------------------------------------------------------------------------------
    mesh_command_OLD_time_event_time                              = 0x0258, // Get/Set the time of event #payload[0], payload[1] as event type as enum time_event_type_enum payload[2] as wdays, bit 0 (lsb) for monday through bit 6 for sunday, payload[3] as hour(0-23), payload[4] as minute(0-59), payload[5] as second(0-59) payload[6-9] as uint32 of repetition counter, set only payload[0] to remove event or empty payload to remove all events
    mesh_command_OLD_time_event_type                              = 0x0259, // Get/Set the type of event #payload[0], as enum mesh_command_time_event_result_e cast of payload[1]
    mesh_command_OLD_time_event_settings_scene                    = 0x025a, // Get/Set the scene payload[2 for time event, 3 for astro event] for time event #payload[0] as event type payload[1] as (enum time_event_type_enum event_type) if astro event payload[2]==0 for enter scene and payload[2]==1 for exit scene, payload[3->4 for time event and 4->5 for astroevent] is the new slewrate to use for the scene, the format of slewrate is the same as that of "mesh_command_output_speed"
    mesh_command_time_event_sun_rise                              = 0x025b, // Get/Set sunrise with offset #payload[0], for writes, payload[1->X] is the offsets to write in minutes after midnight in 6minute unit, 36 slots are used and are evenly distributed.
    mesh_command_time_event_sun_set                               = 0x025c, // Get/Set sunset with offset #payload[0], for writes, payload[1->X] is the offsets to write in minutes after midnight in 6minute unit, 36 slots are used and are evenly distributed.
    mesh_command_time_configure                                   = 0x025f, // MiniPackaged based configuration format to configure different time related configurations
    mesh_command_time_rtc                                         = 0x0260, // Get payload[0] device id 0 = internal, 1 = faceplate. Set payload[0] deivce id payload[1-8] time in milliseconds (big endian)
    mesh_command_time_rtc_sync_mode                               = 0x0263, // X = payload[0]. X == 0: sync periodically, X == 1: sync only exact time.
    mesh_command_time_time_event_boot_trigger                     = 0x0264, // X = payload[0]. X == 0: dont trigger time events at boot. X == 1: Trigger time events at boot.
    mesh_command_OLD_astro_event_enable                           = 0x0261, // Get/set the enable state of an astro event (Set: payload[0] == event number, payload[1] = state)
    mesh_command_time_bat00_configure                             = 0x0262, // Get/Set settings->time.bat00.selftest, skip correction factor on set, empty set trigger recalibration
    mesh_command_universal_time_event                             = 0x0270, // Astro and weektimer configuration
    mesh_command_universal_time_scene_off                         = 0x0271, // Set off-scene for universal time events on window coverings
    // 0x02bc - 0x02ed (   700 -    749)                                    ------ FACEPLATE -----------------------------------------------------------------------------------
    // 0x02ee - 0x031f (   750 -    799)                                    ------ DEBUG ---------------------------------------------------------------------------------------
    mesh_command_debug1                                           = 0x02ee, // Get/Set the debug 1 value payload[0]
    mesh_command_debug2                                           = 0x02ef, // Get/Set the debug 2 value payload[0]
    mesh_command_debug3                                           = 0x02f0, // Get/Set the debug 3 value payload[0-1]
    mesh_command_debug4                                           = 0x02f1, // Get/Set the debug 4 value payload[0-1]
    mesh_command_debug5                                           = 0x02f2, // Get/Set the debug 5 value payload[0-3]
    mesh_command_debug6                                           = 0x02f3, // Get/Set the debug 6 value payload[0-3]
    // 0x0320 - 0x03ff (   800 -   1023)                                    ------ MISC ----------------------------------------------------------------------------------------
    mesh_command_temporary_index                                  = 0x0323, // Set temporary index for MAC(payload[0-5]) as payload[6] for either payload[7] number of incomming package or payload[8-9] 20ms cycles, whichever occurs first. Any Set on broadcast clears all temporary index
    mesh_command_installation                                     = 0x0324, // TODO
    mesh_command_fellowship_scanning                              = 0x0325, // TODO
    mesh_command_device_index                                     = 0x0326, // Get or Set device index
    mesh_command_traffic_max_age                                  = 0x0327, // Get/Set max age for traffic avoidance
    mesh_command_testing_default_mesh_override                    = 0x0328, // Force default mesh for testing.
    mesh_command_indicate_mac                                     = 0x0329,
    mesh_command_fellowship_part_1                                = 0x032a,
    mesh_command_fellowship_part_2                                = 0x032b,
    mesh_command_fellowship_part_3                                = 0x032c,
    mesh_command_fellowship_app_com                               = 0x032d,
    mesh_command_fellowship_cancel                                = 0x032e,
    mesh_command_fellowship_scanning_age                          = 0x032f,
    mesh_command_fellowship_scanning_params                       = 0x0330,
    mesh_command_fellowship_default_mesh                          = 0x0331, // Override the access address for the default mesh
    mesh_command_fellowship_verify                                = 0x0332,

    mesh_command_humidity                                         = 0x0342,

    mesh_command_lowpower_stay_on_mesh                            = 0x0026, // Set time to stay on mesh, payload[0-1] as uint16 in 20ms time units, 0 will cause the device to drop from mesh and max time is 60seconds
    mesh_command_lowpower_time_to_stay_on_mesh_after_button_release = 0x0320, // Get/Set time to stay on mesh after button release as payload[0->1] as uint16_t in 20ms unit
    mesh_command_lowpower_time_to_stay_on_ble                     = 0x0321, // Get/Set time to stay on ble after mesh disable as payload[0->1] as uint16_t in 20ms unit

    mesh_command_raw_setting                                      = 0x0380, // Raw settings read/write
    mesh_command_persistent_storage                               = 0x0381,

    mesh_command_version_sync                                     = 0x1011, // Used as dummy command to broadcast version to WPH
    //NEW V3 FUNCTIONS V3
    //========================================================================================================
    // 0x0400 - 0x041f (       -       )                                    ------ SYSTEM REGION -------------------------------------------------------------------------------
    mesh_command_get_handle_version                               = 0x0400, // Send mesh handle and get 1b status code and 2b version.
    mesh_command_get_cpu_load                                     = 0x0401, // TODO Add a description
    mesh_command_get_cycles_since_boot                            = 0x0402, // Fetches a 32bit integer representing number of 20ms loops executed. To be used as a up timer.
    mesh_command_is_protected                                     = 0x0403, // Function to check if readout protection is set or not.
    // 0x0420 - 0x043f (       -       )                                    ------ OUTPUT REGION -------------------------------------------------------------------------------
    mesh_command_output_set                                       = 0x0420, // Updates a output using a index. Will also store data into output announce.
    // 0x0440 - 0x045f (       -       )                                    ------ INPUT REGION --------------------------------------------------------------------------------

    //PRODUCT FUNCTIONS: Functions that is implemented by the product
    //========================================================================================================
    //MULTIPLE                                                              ----------------------------------------------------------------------------------------------------
    mesh_command_output_curve_type                                = 0x00cc, // Get/Set the output #payload[0] curve type as a mesh_commands_curve_type_enum cast from payload[1] with extra settings at payload[2->]
    mesh_command_product_revision                                 = 0x00dd, // Get the product revision as uint32_t payload[0-3]
    //DIM-01, DIM-02, DIM-01-2P, DIM-01-LC, SPD-01
    mesh_command_output_dimmer_control_params                     = 0x00e0, // Get/Set control params for dimmers, settings->settings_product_specific.dimmer_conf
    mesh_command_set_blanking_time                                = 0x00e1, // Get/Set blanking time (uint16_t) LE in payload[0-1]
    // DIM-01-2P
    mesh_command_trigger_overcurrent                              = 0x0389, // Set to trigger an overcurrent reaction
    //DIM-01, DIM-02                                                        ----------------------------------------------------------------------------------------------------
    mesh_command_output_phase_dim_type                            = 0x00ce, // Get/Set the output #payload[0] type for as enum mesh_command_phase_dim_output_type_enum cast from payload[1]
    mesh_command_output_time_before_zcd                           = 0x00d6, // Get/Set the time to turn on the output before zerocrossing for output #payload[0] as uint8_t in payload[1] in 20us unit, 0 default, 75 for loads that causes DIM01 to reboot
    mesh_command_max_output_power                                 = 0x0227, // Get the max output power as uint16_t payload[0-1] in 1W units
    mesh_command_output_rms_current                               = 0x0228, // Get the output RMS current as uint16_t payload[0-1] in 10mA units, example: 1A=100, 5A=500
    mesh_command_outout_relay_config                              = 0x022a, //
    //DIM-01                                                                ----------------------------------------------------------------------------------------------------
    mesh_command_output_power                                     = 0x0226, // Get the output power as uint16_t payload[0-1] in 1W units
    //CTR-01, LED-10                                                        ----------------------------------------------------------------------------------------------------
    mesh_command_input_phase_read_window                          = 0x0196, // Get/Set the input read window, payload[0->1] as int16_t of window_center_from_top_of_size_offset_us, payload[2->3] as uint16_t of total_window_width_us
    //CTR-01                                                                ----------------------------------------------------------------------------------------------------
    mesh_command_output_minimum_relay_off_time                    = 0x00d4, // Get/Set the minimum relay off time for output #payload[0] as uint16_t in 10ms units in payload[1->2]
    mesh_command_output_0_10V_mode                                = 0x01c2, // Get/set the 0-10V output mode, for output #payload[0] as payload[1] casted as mesh_commands_output_0_10V_mode_enum
    mesh_command_output_0_10V_pullup                              = 0x01c3, // Get/set for output #payload[0] the pullup state as bool (payload[1])
    mesh_command_output_relay_timing_conf                         = 0x01c4, // Get/Set for output #payload[0], payload[1->2] is uint16 of engage_time_us, payload[3->4] is uint16_t of release_time_us, payload[5->6] is int16_t of engage_offset_time_us, payload[7->8] is int16_t of release_offset_time_us, payload[9] as enum mesh_commands_output_relay_phase_enum of release_phase, payload[10] as enum mesh_commands_output_relay_phase_enum of engage_phase
    mesh_command_output_safety_timer_configure                    = 0x01c6, // Get/Set for output #payload[0], payload[1->3] is uint24 of timer lenght in 20ms, payload[4] is uint8_t of configuration flags: bit[0] sets if the timer is active, bit[1] sets if the timer can be extended, bit[2] sets if the timer's duration can be overwritten without changing settings
    mesh_command_output_timer_duration                            = 0x01c7, // Get/Set for output #payload[0], payload[1->3] is uint24 of the current timer duration in 20ms
    mesh_command_testing_get_relay_cycles                         = 0x003e, // Get number of relay cycles for output #Payload[0] as uint32_t Payload[1->4]
    //LED75
    mesh_command_led75_output_mode                                = 0x01c8,
    mesh_command_led75_configure                                  = 0x01c9,
    //LED-10                                                                ----------------------------------------------------------------------------------------------------
    mesh_command_read_ctrlsensor                                  = 0x01f8, // Returns the voltage on the control pin in regulator loop.
    mesh_command_set_led                                          = 0x01f9, // Set LED load type and voltage or current
    //Armature
    mesh_command_light_directions                                 = 0x0200, // Configure differential light levels for single output, multi light armatures
    mesh_command_cct_calibration                                  = 0x0201, // Get/Set the product specific CCT calibration table
    mesh_command_light_buck_controller_error                      = 0x0202, // Get/Set settings and get state of self-test for buck controller
    //Tunable lights
    mesh_command_tunable_white_temperature                        = 0x0101, // Get/Set temperature u16 payload[1-2] for tunable white load for output[payload[0]]. If payload_len == 1 disable eventual override
    mesh_command_tunable_white_configure                          = 0x0102, // TODO
    mesh_command_tunable_calibration                              = 0x0104,
    mesh_command_tunable_black_body                               = 0x0105,
    mesh_command_group_tunable_white_temperature_range            = 0x0107, // Get temperature ang range for an index, payload defined in mesh_command_tunable_white_temperature_range_payload_t

    // Luminaire
    mesh_command_testing_luminaire_duty                           = 0x01cb, // Override the luminaire duty: uint16_t power duty, uint16_t color duty. Both 0-0xFFFF.

    // DWN
    mesh_command_dwn01_configure                                  = 0x01ca,
    mesh_command_dwn01_led_burn_time                              = 0x01e0,
    mesh_command_dwn01_lumen_cct_verification                     = 0x01e1, // Override the color and level and set CCT and Lumen directly with physical values: uint16_t [centi-lumen], uint16_t [deci-kelvin]
    mesh_command_dwn01_lumen_color_duty                           = 0x01e8, // Override the color and level. Set a specific lumen and color duty.
    mesh_command_dwn01_calibration_individual                     = 0x01e2, // Apply individual calibration parameters. Set/get in the following order: G0, G1, k, m. A set will also update the output. NB: rescaled values!
    mesh_command_dwn01_calibration_min_max                        = 0x01e3, // Set/get in the following order: min luminosity, max luminosity, min color temperature, max color temperature. NB: rescaled values!
    mesh_command_dwn01_calibration_color_duty_table               = 0x01e4, // Write/Read the color duty table (to normalize and linearize color temperature)
    mesh_command_dwn01_calibration_luminosity_table               = 0x01e5, // Write/Read the luminosity table (for limiting max luminosity to the curren color temperature)
    mesh_command_dwn01_calibration_power_duty_table               = 0x01e6, // Write/Read the power duty table (to linearize the level to power duty)
    mesh_command_dwn01_calibration_power_color_gain_table         = 0x01e7, // Write/Read the color gain table (to linearize the level to the current color temperature)
    mesh_command_dwn01_calibration_source                         = 0x01e9, // Get the source for calibration in use
    mesh_command_dwn01_calibration_commit                         = 0x01eb, // Forces a load of the calibration, i.e. loads the calibration from settings to the buck mapping module
    mesh_command_dwn01_test_max_power_duty                        = 0x01ea, // Set the output to the maximum power duty found in calibration. (Get will reply with the power duty)
    mesh_command_dwn01_calibration_choose_default                 = 0x01ec, // Set only. Set the default calibration to use. Only valid before UICR has been written. Intended for production station to set before performing calibration.

    // OUT-01
    mesh_command_out01_configure                                  = 0x01d0,
    mesh_command_out01_led_burn_time                              = 0x01d1,
    mesh_command_out01_test_power_dump                            = 0x01d2,
    mesh_command_out01_calibration_individual                     = 0x01d3, // Set and apply individual calibration parameters. Order: k, m.
    mesh_command_out01_calibration_min_max                        = 0x01d4, // Set/get in the following order: luminosity_resolution, max luminosity, min color temperature, max color temperature. NB: rescaled values!
    mesh_command_out01_calibration_color_duty_table               = 0x01d5, // Write/Read the color duty table (to normalize and linearize color temperature)
    mesh_command_out01_calibration_power_duty_single_table        = 0x01d6, // Write/Read the power duty table for single channel mode (to linearize the level to power duty).
    mesh_command_out01_calibration_power_duty_double_table        = 0x01d7, // Write/Read the power duty table for double channel mode (to linearize the level to power duty).
    mesh_command_out01_calibration_source                         = 0x01d8, // Get the source for calibration in use
    mesh_command_out01_calibration_commit                         = 0x01d9, // Forces a load of the calibration, i.e. loads the calibration from settings to the buck mapping module

    // OUT-02
    mesh_command_out02_configure                                  = 0x01f0,
    mesh_command_out02_calibration_individual                     = 0x01f1, // Set and apply individual calibration parameters. Order: k, m.
    mesh_command_out02_calibration_min_max                        = 0x01f2, // Set/get in the following order: luminosity_resolution, max luminosity, min color temperature, max color temperature. NB: rescaled values!
    mesh_command_out02_calibration_color_duty_table               = 0x01f3, // Write/Read the color duty table (to normalize and linearize color temperature)
    mesh_command_out02_calibration_power_duty_table               = 0x01f4, // Write/Read the power duty table (to linearize the level to power duty).
    mesh_command_out02_calibration_source                         = 0x01fa, // Get the source for calibration in use
    mesh_command_out02_calibration_commit                         = 0x01fb, // Forces a load of the calibration, i.e. loads the calibration from settings to the buck mapping module

    // CCL-01
    mesh_command_ccl01_configure                                  = 0x0210,
    mesh_command_ccl01_test_mode                                  = 0x0211,
    mesh_command_ccl01_reset_sensors                              = 0x0212,
    mesh_command_testing_get_ac_led_strings                       = 0x0213, // Read current number of strings selected and driver-voltage

    //GWY-01                                                                ----------------------------------------------------------------------------------------------------
    mesh_command_gateway_voltage_3v3                              = 0x0348, // Get voltage of NRF VCC (calls mesh_command_testing_get_2V5_rail_voltage). voltage in mV payload[0-1] as uint16
    mesh_command_gateway_voltage_1v8                              = 0x0349, // Get voltage of the 1.8V rail. voltage in mV payload[0-1] as uint16
    mesh_command_gateway_voltage_1v2                              = 0x034a, // Get voltage of the 1.2V rail. voltage in mV payload[0-1] as uint16
    mesh_command_gateway_factory_key                              = 0x0352, // Sent by the app to a gateway to Get a hashed version of the FactoryKey which is installed on the gateway payload[0-15]
    mesh_command_gateway_resource_set                             = 0x0353, // Sent by app to gateway to Set resource set ID payload[0-9], Resource Set Scopes (bit field) payload[10]
    mesh_command_gateway_site_id                                  = 0x0354, // App sends command to Set Site ID (UUIDv4 represented as 16 hexadecimal bytes) payload[0-15]
    mesh_command_gateway_request_button_press                     = 0x0355, // App sends command to start the process for allowing the user to press the physical gateway button
    mesh_command_gateway_button_press                             = 0x0356, // Sent by gateway to app, to inform it of the physical gateway button having been pressed. ResourceSetID installed on the gateway (10 ASCII characters, A-Za-z0-9) payload[0-9]
    mesh_command_gateway_dhcp_setting                             = 0x0357, // Get/Set DHCP enabled. DHCP byte (Enabled: 0x01, Disabled: 0x00) payload[0]
    mesh_command_gateway_assigned_ip                              = 0x0358, // Get/Set a static IP to the gateway. IPV4 payload[0-3] or IPV6 payload[0-15]
    mesh_command_gateway_subnet_mask                              = 0x0359, //Get/Set subnet mask. IPV4 payload[0-3]
    mesh_command_gateway_ipv6_prefix_length                       = 0x035a, // Get/Set IPV6 prefix length. IPv6 Prefix Length (0-128) payload[0]
    mesh_command_gateway_default_gateway_ip                       = 0x035b, // Get/Set default gateway. IPV4 payload[0-3] or IPV6 payload[0-15]
    mesh_command_gateway_dns_server_ip                            = 0x035c, // Get/Set DNS server. IPV4 payload[0-3] or IPV6 payload[0-15]
    mesh_command_gateway_network_status                           = 0x035d, // Get network status. Status bits (Ethernet link connected, Remote access established) payload [0]//
    mesh_command_gateway_led_default_state                        = 0x035e,
    //WRP-01, WPH-01                                                        ----------------------------------------------------------------------------------------------------
    mesh_command_input_click_count                                = 0x0197, // Get number of clicks on input payload[0] as uint32_t of payload[1->4]
    mesh_command_input_double_click_count                         = 0x0198, // Get number of double clicks on input payload[0] as uint32_t of payload[1->4]
    mesh_command_input_dim_count                                  = 0x0199, // Get number of dim cycles on input payload[0] as uint32_t of payload[1->4]
    mesh_command_wph02_sensor_read                                = 0x019b, // Read WPH02 sensors (2x uint16, 0-1023)
    mesh_command_input_rotation_count                             = 0x0103, // Get number of rotations for input payload[0] as uint32_t of payload[1->4] LE
    //REL-01                                                                ----------------------------------------------------------------------------------------------------
    mesh_command_output_relay_timing                              = 0x00da, // Get/Set the relay timing for output #payload[0] as turn on delay us in payload[1->2] as int16 and turn off delay us in payload[3->4] as int16
    //DLI-01
    mesh_command_dali_get_number_of_connected_slaves              = 0x0384, //Result in payload[0]
    mesh_command_dali_slave_output_grouping                       = 0x0385, //Set slave #payload[0] to be included in output #payload[1], Get which output slave #payload[0] is included in (result in paytload[1]), output #255 is no inclusion
    mesh_command_dali_identify_slave                              = 0x0386, //Identify slave #payload[0], 255 for all slaves, slave will go to 0% for 1 second then 100% again
    mesh_command_dali_get_slave_info                              = 0x038a, //slave # as payload[0], payload[1]=physical min, payload[2-3] = uint16_t of warmest CCT, payload[4->5] = uint16_t of coldest CCT
    mesh_command_dali_discover                                    = 0x038b, // Discover slaves
    mesh_command_dali_configure                                   = 0x038c, // DALI configuration using MiniPkg
    mesh_command_dali_bus_command                                 = 0x038d,

    // SPR-01
    mesh_command_get_off_time_estimate                            = 0x0387, // Get the estimation of how long the device was turned off in payload[0->3] (seconds)
    mesh_command_indicator_led_config                             = 0x0388, // Get/set the functionality of the indicator LED (TODO: Create spec for LED config)
    mesh_command_spr_configure                                    = 0x038e, // Configure multiple SPR settings at once
    mesh_command_spr_relay_steps                                  = 0x038f,

    // ROL-01
    mesh_command_rol_configure                                    = 0x0280, // ROL-01 configuration using product settings
    mesh_command_rol_move_override                                = 0x0282, // Move ROL-01 without limits. Direct control of output.
    mesh_command_rol_governor_mode                                = 0x0288, // Set/get the control mode used by governor.
    mesh_command_rol_endstop_calibration                          = 0x028f, // Start a calibration run.
    mesh_command_rol_endstop_hard_iron_offset                     = 0x0290, // Get or apply the hard iron offset for magnetometer.
    mesh_command_rol_hbridge                                      = 0x0291, // R0L-01 control hbridge directly (for development purposes)
    mesh_command_rol_soft_start                                   = 0x0292, // Soft start testing

    // JAL-01
    mesh_command_jal_configure                                    = 0x0300, // JAL-01 configuration using product settings
    mesh_command_jal_calibrate_level                              = 0x0302, // JAL-01 calibration of absolute level
    mesh_command_jal_calibration_status                           = 0x0303, // JAL-01 calibration status reporting
    mesh_command_jal_calibration_go_to_endstop                    = 0x0304, // JAL-01 calibration driver control
    mesh_command_jal_calibration_timed_move                       = 0x0305, // JAL-01 calibration move control
    mesh_command_jal_set_level                                    = 0x0306, // JAL-01 set level
    mesh_command_jal_calibration_reset                            = 0x0307, // JAL-01 reset calibration
    mesh_command_jal_calibration_stop                             = 0x0308, // JAL-01 Stop calibration (only in open loop control)

    // WMS-01
    mesh_command_wms01_configure                                  = 0x0430, // WMS-01 configuration using product settings
    mesh_command_wms01_status_reporting                           = 0x0431, // Command for wms specific status reporting interface
    mesh_command_wms01_test_mode                                  = 0x0432, // Command for wms test mode
    mesh_command_wms01_uptime                                     = 0x0433, // Command for wms uptime
    mesh_command_ambient_light_sensor                             = 0x0434, // Command for ambient light sensor on all products that support ambient light
    mesh_command_wms01_motion_timeout                             = 0x0435, // Command for motion timeout on WMS.

    // TRM-0X
    mesh_command_trm_read_sensors                                 = 0x0453,
    mesh_command_trm_diagnostic_1                                 = 0x0454, // TRM alpha diagnostic command (part 1)
    mesh_command_trm_diagnostic_2                                 = 0x0455, // TRM alpha diagnostic command (part 2)
    mesh_command_trm_diagnostic_3                                 = 0x0456, // TRM alpha diagnostic command (part 3)
    mesh_command_trm_diagnostic_4                                 = 0x0457, // TRM alpha diagnostic command (part 4)
    mesh_command_trm_floor_temperature_sensor_available           = 0x0458, // Get the availability of the floor temperature sensor
    mesh_command_trm_floor_temperature_sensor_config              = 0x0459, // Get/Set the configuration of the floor temperature sensor
    mesh_command_trm_floor_sensor_resistance_reading              = 0x045A, // Get the resistance reading of the floor temperature sensor
    mesh_command_trm_temperature_reading                          = 0x045B, // Get the temperature reading of the floor or room temperature sensor
    mesh_command_trm_temperature_regulating_set_point             = 0x045C, // Set/get, 2 byte, 0.1°C, range 0 - 400
    mesh_command_trm_temperature_regulating_hysteresis            = 0x045D, // Set/get, 1 byte, 0.1°C, range 0 - 100
    mesh_command_trm_regulating_mode                              = 0x045E, // Set/get, Floor-, Room- or Time-regulation.
    mesh_command_trm_operating_mode                               = 0x045F, // Set/get, Normal-, Boost-, Frost-protection-, Vacation-, Curing- or Service-operation.
    mesh_command_trm_temperature_limits                           = 0x0460, // Set/get, 1 byte limit (enum), 2 byte temperature (0.1°C unit)
    mesh_command_trm_pwm_duty                                     = 0x0461, // Set/get, 1 byte, %, range 0 - 100
    mesh_command_trm_pwm_period                                   = 0x0462, // Set/get, 1 byte, minutes, range 5 - 60
    mesh_command_trm_pwm_limits                                   = 0x0463, // Set/get, 1 byte limit (enum), 1 byte min_value (0-100%), 1 byte max_value (0-100%)
    mesh_command_trm_daytime_reduction_config                     = 0x0464, // Set/get a daytime reduction schedule
    mesh_command_trm_nighttime_reduction_config                   = 0x0465, // Set/get a nighttime reduction schedule
    mesh_command_trm_graphic_language                             = 0x0466, // Set/get the graphic language
    mesh_command_trm_graphic_image_banks                          = 0x0467, // Get the graphic image bank meta data
    mesh_command_trm_installation_confirm                         = 0x0468, // Confirm installation
    mesh_command_trm_daytime_reduction_setpoint                   = 0x0469, // Set/get the daytime reduction setpoint
    mesh_command_trm_nighttime_reduction_setpoint                 = 0x046A, // Set/get the nighttime reduction setpoint
    mesh_command_trm_screen_saver_config                          = 0x046B, // Set/get the screen saver configuration
    mesh_command_trm_screen_color_test                            = 0x046C, // Test the screen by drawing colored squares
    mesh_command_trm_screen_lock                                  = 0x046D, // Set/get the screen lock
    mesh_command_testing_trm_get_view                             = 0x046E, // Get the current view
    mesh_command_testing_trm_click_screen                         = 0x046F, // Click the screen at a specific location
    mesh_command_trm_model_parameters                             = 0x0470, // Set/get the model parameters
    mesh_command_trm_cost_control                                 = 0x0471, // Set/get the cost control
    mesh_command_trm_diagnostic_5                                 = 0x0472, // TRM alpha diagnostic command (part 5)
    mesh_command_trm_diagnostic_6                                 = 0x0473, // TRM alpha diagnostic command (part 6)
    mesh_command_trm_diagnostic                                   = 0x0474, // TRM diagnostic command
    mesh_command_trm_viewmock_set_view                            = 0x0475, // TRM force view (for debugging)
    mesh_command_trm_testing_room_estimation                      = 0x0476, // TRM room estimation (for debugging)
    mesh_command_trm_vacation_mode_configure                      = 0x0477, // Set/get the vacation mode configuration
    mesh_command_trm_protection_weld_detection_configure          = 0x0478, // Set/get the protection weld detection configuration
    mesh_command_trm_ambient_light_sensor_configure               = 0x0479, // Set/get the ambient light sensor configuration
    mesh_command_trm_backlight_override                           = 0x047A, // Set/get the backlight override
    mesh_command_trm_last_touch_event                             = 0x047B, // Get the last touch event
    mesh_command_trm_boost_config                                 = 0x047C, // Set/get boost configuration
    mesh_command_trm_vacation_ends                                = 0x047D, // Broadcast of vacation end to all TRMs in the site.
    mesh_command_trm_deactivate_operating_mode                    = 0x047E, // Deactivate an operating mode.
    mesh_command_trm_regulator_config                             = 0x047F,  // Set/get config for the room with floor regulator
    mesh_command_trm_diagnostic_7                                 = 0x0480, // TRM new room_floor controller debug (temporary cmd)
    mesh_command_trm_diagnostic_8                                 = 0x0481, // TRM new room_floor controller debug (temporary cmd)
    mesh_command_trm_diagnostic_9                                 = 0x0482, // TRM new room_floor controller debug (temporary cmd)
    mesh_command_trm_curing_mode_info                             = 0x0483, // Get curing mode info.
    mesh_command_trm_delayed_start                                = 0x0484, // Set/get delayed start duration.
    mesh_command_trm_protection_errors                            = 0x0485, // Get/clear protection errors
    mesh_command_trm_backlight_levels                             = 0x0486, // Set/get backlight levels
    mesh_command_trm_backlight_rate_of_change                     = 0x0487, // Set/get backlight rate of change
    mesh_command_trm_guesstimate_config                           = 0x0488, // Set/get guesstimate configuration

    // SPD-01
    mesh_command_spd_configure                                    = 0x0500, // SPD-01 configuration using product settings

    //========================================================================================================

    mesh_command_conn_params                                      = 0x1337,
    mesh_command_factory_reset_reason                             = 0x1338,
    mesh_command_write_to_uicr_send_factory_reset_and_send_carrier = 0x1339,
    mesh_command_read_uicr_raw                                    = 0x133A,

    //DEPRECATED FUNCTIONS: Commands used for backwards compatibility with V2 and will be removed after V3
    //========================================================================================================
    // 0x0032 - 0x0095 (    50 -     99)                                    ------ TESTING -------------------------------------------------------------------------------------



    //REMOVED FUNCTIONS: These command indexes will be free after V3
    //========================================================================================================
    mesh_command_REMOVED_0001                                  = 0x0001, // =========== DELETED ===========
    mesh_command_REMOVED_0002                                  = 0x0002, // =========== DELETED ===========
    mesh_command_REMOVED_0009                                  = 0x0009, // =========== DELETED ===========
    mesh_command_REMOVED_000a                                  = 0x000a, // =========== DELETED ===========
    mesh_command_REMOVED_000b                                  = 0x000b, // =========== DELETED ===========
    mesh_command_REMOVED_000c                                  = 0x000c, // =========== DELETED ===========
    mesh_command_REMOVED_0012                                  = 0x0012, // =========== DELETED ===========
    mesh_command_REMOVED_0013                                  = 0x0013, // =========== DELETED ===========
    mesh_command_REMOVED_0014                                  = 0x0014, // =========== DELETED ===========
    mesh_command_REMOVED_0017                                  = 0x0017, // =========== DELETED ===========
    mesh_command_REMOVED_0018                                  = 0x0018, // =========== DELETED ===========
    mesh_command_REMOVED_0019                                  = 0x0019, // =========== DELETED ===========
    mesh_command_REMOVED_0020                                  = 0x0020, // =========== DELETED =========== (mesh_command_frequency) Get set the frequency system payload[0] as enum mesh_command_frequency_enum
    mesh_command_REMOVED_0022                                  = 0x0022, // =========== DELETED =========== (mesh_command_configure_scene)
    mesh_command_REMOVED_002f                                  = 0x002f, // =========== DELETED =========== (mesh_command_rf_speed) Get/Set the rf_speed parameter used by the different rf_channels (mesh_command_frequency)
    mesh_command_REMOVED_001a                                  = 0x001a, // =========== DELETED ===========
    mesh_command_REMOVED_0039                                  = 0x0039, // =========== DELETED =========== (mesh_command_testing_get_burn_time)
    mesh_command_REMOVED_003a                                  = 0x003a, // =========== DELETED ===========
    mesh_command_REMOVED_003b                                  = 0x003b, // =========== DELETED ===========
    mesh_command_REMOVED_003c                                  = 0x003c, // =========== DELETED ===========
    mesh_command_REMOVED_0064                                  = 0x0064, // =========== DELETED ===========
    mesh_command_REMOVED_0065                                  = 0x0065, // =========== DELETED ===========
    mesh_command_REMOVED_0066                                  = 0x0066, // =========== DELETED ===========
    mesh_command_REMOVED_0067                                  = 0x0067, // =========== DELETED ===========
    mesh_command_REMOVED_0068                                  = 0x0068, // =========== DELETED ===========
    mesh_command_REMOVED_0099                                  = 0x0099, // =========== DELETED ===========
    mesh_command_REMOVED_009a                                  = 0x009a, // =========== DELETED =========== (mesh_command_group_output_query_levels) Get max level for groups in list A of uint8_t(payload[A[n]]), if len(payload) == 0, get array of max of all groups for each output
    mesh_command_REMOVED_00cd                                  = 0x00cd, // =========== DELETED =========== (mesh_command_output_curve_data) Get/Set the curve optional data payload[2->x] this can be unique to each curve type
    mesh_command_REMOVED_00d1                                  = 0x00d1, // =========== DELETED =========== (mesh_command_output_self_learn) Get/Set the self learn enable feature for output #payload[0] as a bool in payload[1] for usage and as bool in payload[2] for learn
    mesh_command_REMOVED_00d2                                  = 0x00d2, // =========== DELETED =========== (mesh_command_output_self_learn_state) Get/Set the self learn table for output #payload[0] with offset payload[1], sunstate payload[2] and payload[3->3+(2*X)] are of type struct self_learn_entry_struct
    mesh_command_REMOVED_00d3                                  = 0x00d3, // =========== DELETED =========== (mesh_command_output_announce_config) Get/Set the output announce config for output #payload[0] as struct output_announce_config_struct in payload[1->X]
    mesh_command_REMOVED_00d8                                  = 0x00d8, // =========== DELETED ===========
    mesh_command_REMOVED_00d9                                  = 0x00d9, // =========== DELETED ===========
    mesh_command_REMOVED_00fc                                  = 0x00fc, // =========== DELETED ===========
    mesh_command_REMOVED_0100                                  = 0x0100, // =========== DELETED ===========
    mesh_command_REMOVED_0106                                  = 0x0106, // =========== DELETED =========== (mesh_command_tunable_white_temperature_range) Get temperature ang range for an output, payload defined in mesh_command_tunable_white_temperature_range_payload_t
    mesh_command_REMOVED_012e                                  = 0x012e, // =========== DELETED ===========
    mesh_command_REMOVED_015f                                  = 0x015f, // =========== DELETED ===========
    mesh_command_REMOVED_0160                                  = 0x0160, // =========== DELETED ===========
    mesh_command_REMOVED_01c5                                  = 0x01c5, // =========== DELETED =========== Get COM connector for REL-01 payload[0] as COM_connection_enum
    mesh_command_REMOVED_01f5                                  = 0x01f5, // =========== DELETED ===========
    mesh_command_REMOVED_01f6                                  = 0x01f6, // =========== DELETED ===========
    mesh_command_REMOVED_01f7                                  = 0x01f7, // =========== DELETED ===========
    mesh_command_REMOVED_025d                                  = 0x025d, // =========== DELETED =========== (mesh_command_time_event_conf)   ??
    mesh_command_REMOVED_025e                                  = 0x025e, // =========== DELETED =========== (mesh_command_astro_event_conf)  ??
    mesh_command_REMOVED_028a                                  = 0x028a, // =========== DELETED ===========
    mesh_command_REMOVED_028b                                  = 0x028b, // =========== DELETED ===========
    mesh_command_REMOVED_0229                                  = 0x0229, // =========== DELETED ===========
    mesh_command_REMOVED_02bc                                  = 0x02bc, // =========== DELETED =========== (mesh_command_faceplate_config)  Get/Set data in struct faceplate_push_struct when push faceplate is attached, payload[0] is offset payload[1] is length ang payload[2->X] is data
    mesh_command_REMOVED_0301                                  = 0x0301, // JAL-01 manage travel time calibration
    mesh_command_REMOVED_0322                                  = 0x0322, // =========== DELETED ===========
};

#endif /* PLEJD_MESH_INCLUDE_PLEJD_MESH_COMMANDS_H_ */
