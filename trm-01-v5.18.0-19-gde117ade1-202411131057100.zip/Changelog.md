# Changelog

## cfiw-v5.18.0 vs. [Unreleased]

### Added
* Add option to select the gamma correction factor application order by product.

### Fixed
* Transitioning to Service/Curing/Vacation mode from Frost Protection mode did not deactivate Frost Protection mode. Now it does.
* Curing view did not update when the expiration date changed.
* Vacation setpoint now saturates on new limits.
* Increased screen saver brightness.
* Centered clock on screensaver
* Fix bug where some relay transitions could trigger that watchdog.
* Repair cost control for "Room with Floor Sensor" regulation.

### Changed
* Re-introduced bumping relay-duty to 100% for a short while at regular intervals. To prevent accidental disengage of the relays.
